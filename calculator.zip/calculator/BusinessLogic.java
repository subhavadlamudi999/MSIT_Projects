
package calculator;

import javafx.scene.control.Label;

/**
 * <p> Title: BusinessLogic Class. </p>
 * 
 * <p> Description: The code responsible for performing the calculator business logic functions. 
 * This class performs the business logic of the calculator by using three CalculatorValues and 
 * performs actions with and on them.  The class expects data from the User Interface to arrive
 * as Strings and returns Strings to it.  This class calls the CalculatorValue class to do the 
 * computations and this class knows nothing about the actual representation of CalculatorValues,
 * that is the responsibility of the CalculatorValue class and the classes it calls.  Hiding the 
 * representation of calculator values from the business logic means that this code does not have
 * to change when there is a change in the representation changes. Similarly, the this class does
 * not need to change if aspects of the user interface changes.</p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2019 </p>
 * 
 * @author Lynn Robert Carter
 * 
 * @version 4.01	2019-02-08 Enhancements to the documentation 
 * @version 4.00	2014-10-18 The JavaFX-based GUI implementation of a long integer calculator 
 * 
 */

public class BusinessLogic {
	
	/**********************************************************************************************

	Attributes
	
	**********************************************************************************************/
	
	// These are the major calculator values 
	private CalculatorValue operand1 = new CalculatorValue(0);
	private CalculatorValue operand2 = new CalculatorValue(0);
	private CalculatorValue result = new CalculatorValue(0);
	
	private CalculatorValue err_operand1 = new CalculatorValue(0);
	private CalculatorValue err_operand2 = new CalculatorValue(0);
	private CalculatorValue err_result = new CalculatorValue(0);
	
	private String operand1ErrorMessage = "";
	private boolean operand1Defined = false;
	private String operand2ErrorMessage = "";
	private boolean operand2Defined = false;
	private String resultErrorMessage = "";
	private String err_operand1ErrorMessage = "";
	

	private boolean err_operand1Defined = false;
	private String err_operand2ErrorMessage = "";
	private boolean err_operand2Defined = false;
	private String err_resultErrorMessage = "";
	
	

	/**********************************************************************************************

	Constructors
	
	**********************************************************************************************/
	
	/**********
	 * This method initializes all of the elements of the business logic aspect of the calculator.
	 * There is no special computational initialization required, so the initialization of the
	 * attributes above are all that are needed.
	 */
	public BusinessLogic() {
	}

	/**********************************************************************************************

	Getters and Setters
	
	**********************************************************************************************/
	
	/**********
	 * This public setter takes an input String, checks to see if there is a non-empty input string.
	 * If so, it uses it to create a new CalculatorValue and places it into operand1, any associated
	 * error message is placed into operand1ErrorMessage, and sets the defined flag accordingly.
	 * 
	 * @param value
	 * @return	True if the set did not generate an error; False if there was invalid input
	 */
	public boolean setOperand1(String value) {
		operand1Defined = false;						// Assume the operand will not be defined
		if (value.length() <= 0) {						// See if the input is empty. If so no error
			operand1ErrorMessage = "";					// message, but the operand is not defined.
			return true;								// Return saying there was no error.
		}
		operand1 = new CalculatorValue(value);			// If there was input text, try to convert it
		operand1ErrorMessage = operand1.getErrorMessage();	// into a CalculatorValue and see if it
		if (operand1ErrorMessage.length() > 0) 			// worked. If there is a non-empty error 
			return false;								// message, signal there was a problem.
		operand1Defined = true;							// Otherwise, set the defined flag and
		return true;										// signal that the set worked
	}

	
	/**********
	 * This public setter takes an input String, checks to see if there is a non-empty input string.
	 * If so, it uses it to create a new CalculatorValue and places it into operand2, any associated
	 * error message is placed into operand2ErrorMessage, and sets the defined flag accordingly.
	 * 
	 * The logic of this method is the same as that for operand1 above.
	 * 
	 * @param value
	 * @return	True if the set did not generate an error; False if there was invalid input
	 */
	public boolean setOperand2(String value) {			// The logic of this method is exactly the
		operand2Defined = false;							// same as that for operand1, above.
		if (value.length() <= 0) {
			operand2ErrorMessage = "";
			return true;
		}
		operand2 = new CalculatorValue(value);
		operand2ErrorMessage = operand2.getErrorMessage();
		if (operand2ErrorMessage.length() > 0)
			return false;
		operand2Defined = true;
		return true;
	}

		public boolean seterr_Operand1(String value) {
		err_operand1Defined = false;						// Assume the operand will not be defined
		if (value.length() <= 0) {						// See if the input is empty. If so no error
			err_operand1ErrorMessage = "";					// message, but the operand is not defined.
			return true;								// Return saying there was no error.
		}
		err_operand1 = new CalculatorValue(value);			// If there was input text, try to convert it
		err_operand1ErrorMessage = err_operand1.getErrorMessage();	// into a CalculatorValue and see if it
		if (err_operand1ErrorMessage.length() > 0) 			// worked. If there is a non-empty error 
			return false;								// message, signal there was a problem.
		err_operand1Defined = true;							// Otherwise, set the defined flag and
		return true;										// signal that the set worked
	}
	
	public boolean seterr_Operand2(String value) {			// The logic of this method is exactly the
		err_operand2Defined = false;
		// same as that for operand1, above.
		if (value.length() <= 0) {
			err_operand2ErrorMessage = "";
			return true;
		}
		err_operand2 = new CalculatorValue(value);
		
		err_operand2ErrorMessage = err_operand2.getErrorMessage();
		if (err_operand2ErrorMessage.length() > 0)
			return false;
		err_operand2Defined = true;
		return true;
	}
	/**********
	 * This public setter takes an input String, checks to see if there is a non-empty input string.
	 * If so, it uses it to create a new CalculatorValue and places it into result and any 
	 * associated error message is placed into resultErrorMessage.
	 * 
	 * The logic of this method is similar to that for operand1 above. (There is no defined flag.)
	 * 
	 * @param value
	 * @return	True if the set did not generate an error; False if there was invalid input
	 */
	public boolean setResult(String value) {			// The logic of this method is similar to
		if (value.length() <= 0) {							// that for operand1, above.
			operand2ErrorMessage = "";
			return true;
		}
		result = new CalculatorValue(value);
		resultErrorMessage = operand2.getErrorMessage();
		if (operand2ErrorMessage.length() > 0)
			return false;
		return true;
	}
	public boolean err_setResult(String value) {			// The logic of this method is similar to
		if (value.length() <= 0) {							// that for operand1, above.
			err_operand2ErrorMessage = "";
			return true;
		}
		err_result = new CalculatorValue(value);
		err_resultErrorMessage = err_operand2.getErrorMessage();
		if (err_operand2ErrorMessage.length() > 0)
			return false;
		return true;
	}
	/**********
	 * This public setter sets the String explaining the current error in operand1.
	 * 
	 * @return	This method returns nothing, but the operand1ErrorMessage has been set
	 */
	public void setOperand1ErrorMessage(String m) {
		operand1ErrorMessage = m;
		return;
	}
	
	/**********
	 * This public getter fetches the String explaining the current error in operand1, it there is one,
	 * otherwise, the method returns an empty String.
	 * 
	 * @return an error message or an empty String if there was no error
	 */
	public String getOperand1ErrorMessage() {
		return operand1ErrorMessage;
	}
	
	/**********
	 * This public setter sets the String explaining the current error into operand2.
	 * 
	 * @return	This method returns nothing, but the operand2ErrorMessage has been set
	 */
	public void setOperand2ErrorMessage(String m) {
		operand2ErrorMessage = m;
		return;
	}
	
	/**********
	 * This public getter fetches the String explaining the current error in operand2, it there is one,
	 * otherwise, the method returns an empty String.
	 * 
	 * @return an error message or an empty String if there was no error
	 */
	public String getOperand2ErrorMessage() {
		return operand2ErrorMessage;
	}
	
	/**********
	 * This public setter sets the String explaining the current error in the result.
	 * 
	 * @return	This method returns nothing, but the resultErrorMessage has been set
	 */
	public void setResultErrorMessage(String m) {
		resultErrorMessage = m;
		return;
	}
	
	/**********
	 * This public getter fetches the String explaining the current error in the result, it there is one,
	 * otherwise, the method returns an empty String.
	 * 
	 * @return and error message or an empty String if there was no error
	 */
	public String getResultErrorMessage() {
		return resultErrorMessage;
	}
	
	/**********
	 * This public getter fetches the defined attribute for operand1. You can't use the lack of an error 
	 * message to know that the operand is ready to be used. An empty operand has no error associated with 
	 * it, so the class checks to see if it is defined and has no error before setting this flag true.
	 * 
	 * @return true if the operand is defined and has no error, else false
	 */
	public boolean getOperand1Defined() {
		return operand1Defined;
	}
	
	/**********
	 * This public getter fetches the defined attribute for operand2. You can't use the lack of an error 
	 * message to know that the operand is ready to be used. An empty operand has no error associated with 
	 * it, so the class checks to see if it is defined and has no error before setting this flag true.
	 * 
	 * @return true if the operand is defined and has no error, else false
	 */
	public boolean getOperand2Defined() {
		return operand2Defined;
	}

	public String getErr_operand1ErrorMessage() {
		return err_operand1ErrorMessage;
	}

	public void setErr_operand1ErrorMessage(String err_operand1ErrorMessage) {
		this.err_operand1ErrorMessage = err_operand1ErrorMessage;
	}

	public boolean isErr_operand1Defined() {
		return err_operand1Defined;
	}

	public void setErr_operand1Defined(boolean err_operand1Defined) {
		this.err_operand1Defined = err_operand1Defined;
	}

	public String getErr_operand2ErrorMessage() {
		return err_operand2ErrorMessage;
	}

	public void setErr_operand2ErrorMessage(String err_operand2ErrorMessage) {
		this.err_operand2ErrorMessage = err_operand2ErrorMessage;
	}

	public boolean isErr_operand2Defined() {
		return err_operand2Defined;
	}

	public void setErr_operand2Defined(boolean err_operand2Defined) {
		this.err_operand2Defined = err_operand2Defined;
	}

	public String getErr_resultErrorMessage() {
		return err_resultErrorMessage;
	}

	public void setErr_resultErrorMessage(String err_resultErrorMessage) {
		this.err_resultErrorMessage = err_resultErrorMessage;
	}
	/**********************************************************************************************

	The toString() Method
	
	**********************************************************************************************/
	
	/**********
	 * This toString method invokes the toString method of the result type (CalculatorValue is this 
	 * case) to convert the value from its hidden internal representation into a String, which can be
	 * manipulated directly by the BusinessLogic and the UserInterface classes.
	 */
	public String toString() {
		return result.toString();
	}
	
	/**********
	 * This public toString method is used to display all the values of the BusinessLogic class in a
	 * textual representation for debugging purposes.
	 * 
	 * @return a String representation of the class
	 */
	public String debugToString() {
		String r = "\n******************\n*\n* Business Logic\n*\n******************\n";
		r += "operand1 = " + operand1.toString() + "\n";
		r += "     operand1ErrorMessage = " + operand1ErrorMessage+ "\n";
		r += "     operand1Defined = " + operand1Defined+ "\n";
		r += "operand2 = " + operand2.toString() + "\n";
		r += "     operand2ErrorMessage = " + operand2ErrorMessage+ "\n";
		r += "     operand2Defined = " + operand2Defined+ "\n";
		r += "result = " + result.toString() + "\n";
		r += "     resultErrorMessage = " + resultErrorMessage+ "\n";
		r += "*******************\n\n";
		return r;
	}

	/**********************************************************************************************

	Business Logic Operations (e.g. addition)
	
	**********************************************************************************************/
	
	/**********
	 * This public method computes the sum of the two operands using the CalculatorValue class method 
	 * for addition. The goal of this class is to support a wide array of different data representations 
	 * without requiring a change to this class, user interface class, or the Calculator class.
	 * 
	 * This method assumes the operands are defined and valid. It replaces the left operand with the 
	 * result of the computation and it leaves an error message, if there is one, in a String variable
	 * set aside for that purpose.
	 * 
	 * This method does not take advantage or know any detail of the representation!  All of that is
	 * hidden from this class by the ClaculatorValue class and any other classes that it may use.
	 * 
	 * @return a String representation of the result
	 */
	public String addition() {
		String x="";
		result = new CalculatorValue(operand1);
		result.add(operand2);
		System.out.println(operand1+"  "+operand2);
		resultErrorMessage = result.getErrorMessage();
		err_result=new CalculatorValue(err_operand1);
		err_result.add(err_operand2);
		err_resultErrorMessage = err_result.getErrorMessage();
		System.out.println(err_operand1+"  "+err_operand2);
		return result.toString()+"�"+err_result.toString();
		
		
	}
	
	/**********
	 * The following methods are method stubs that need to be implemented.
	 * 
	 * @return
	 */
	public String subtraction() {
		result = new CalculatorValue(operand1);
		result.sub(operand2);
		resultErrorMessage = result.getErrorMessage();
		err_result=new CalculatorValue(err_operand1);
		err_result.add(err_operand2);
		err_resultErrorMessage = err_result.getErrorMessage();
		
		return result.toString()+"�"+err_result.toString();
	}
	
	public String multiplication() {
		result = new CalculatorValue(operand1);
		result.mpy(operand2);
		resultErrorMessage = result.getErrorMessage();
		double oper1=Double.parseDouble(err_operand1.toString());
		double oper2=Double.parseDouble(err_operand2.toString());
		double op1=Double.parseDouble(operand1.toString());
		double op2=Double.parseDouble(operand2.toString());
		double opeer1=(oper1/op1)*100;
		double opeer2=(oper2/op2)*100;
		oper1=Double.parseDouble(result.toString());
		oper2=((opeer1+opeer2)/100)*oper1;
		err_resultErrorMessage = err_result.getErrorMessage();
		// replace this comment with the code required to compute the result.
		
		return result.toString()+"�"+oper2;
	}
	
	public String division() {
		result = new CalculatorValue(operand1);
		result.div(operand2);
		resultErrorMessage = result.getErrorMessage();
		double oper3=Double.parseDouble(err_operand1.toString());
		double oper4=Double.parseDouble(err_operand2.toString());
		double op3=Double.parseDouble(operand1.toString());
		double op4=Double.parseDouble(operand2.toString());
		double opeer3=(oper3/op3)*100;
		double opeer4=(oper4/op4)*100;
		oper3=Double.parseDouble(result.toString());
		oper4=((opeer3+opeer4)/100)*oper3;
		err_resultErrorMessage = err_result.getErrorMessage();
		// replace this comment with the code required to compute the result.
		
		return result.toString()+"�"+oper4;
	}
	
	public String root() {
		result = new CalculatorValue(operand1);
		result.root();
		resultErrorMessage = result.getErrorMessage();
		double oper5=Double.parseDouble(err_operand1.toString());
		double op5=Double.parseDouble(operand1.toString());
		double opeer5=(oper5/op5)*100;
		oper5=Double.parseDouble(result.toString());
		oper5=((opeer5/2)/100)*oper5;
		// replace this comment with the code required to compute the result.
		
		return result.toString()+'�'+oper5;
	}
}
